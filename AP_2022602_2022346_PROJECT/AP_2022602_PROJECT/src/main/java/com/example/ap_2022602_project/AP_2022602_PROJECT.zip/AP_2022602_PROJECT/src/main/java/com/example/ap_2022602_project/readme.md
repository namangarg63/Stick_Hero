This project has been developed by:
1. NAMAN GARG(2022602)
2. PANKAJ KUMAR(2022346)
In this project we have tried to implement some design patterns like FACTORY METHOD,SINGLETON PATTERN,STRATEGY PATTERN.
There are classes like game engine,falling engine animation which are implemented on different OOPS principle.We have tried to give our best possible.
HOW TO START THE GAME:
 1. To run the game we need two images ch_pixel.jpeg,final_sh.png which are there in resoueces folder which when saved in system their relative paths needs to be copied in
    line 66 of GameUI for final_sh.png and line 12 of cherry class. After that most probably it should run in any system.
2.  The main control in the Game is space bar which when pressed does all the required function while cursor press could also start or view some things.
3. To revive the player from the lost state it needs 10 cherries in balance to be revived.
4. Scores are saved and showed to user on main screen on right most extreme side.
5. 